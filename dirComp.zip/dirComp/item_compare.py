# coding=utf-8

import sys
import os


def compare_2files_items(file1, file2):
    res_dic = {}
    with open(file1, "r") as f:
        for line in f.readlines():
            line = line.strip("\n")
            res_dic[line] = "1"

    with open(file2, "r") as f:
        for line in f.readlines():
            line = line.strip("\n")
            if res_dic.has_key(line):
                del res_dic[line]
            else:
                res_dic[line] = "2"
    
    # res_dic contains all diff items between dir and dir2
    if res_dic is not None:
        res_dic = convert_res(res_dic)
       
    return res_dic


def convert_res(dic_diff):
    res_dic = {}
    #1
    for key in dic_diff.keys():
        karr = str(key).split(" ./")
        val = dic_diff[key]     # 1 or 2
        fname = karr[1]
        fsign = str(karr[0]).rstrip(" ")     # md5sum or file info
        if val == "1":
            res_dic[fname] = '%s, -' % fsign    # assert not in dir2

    #2
    for key in dic_diff.keys():
        karr = str(key).split(" ./")
        val = dic_diff[key]     # 1 or 2
        fname = karr[1]
        fsign = str(karr[0]).rstrip(" ")
        if val == "2":
            if res_dic.has_key(fname):
                res_dic[fname] = '%s, %s' % (str(res_dic[fname]).split(",")[0], fsign)  # is not the same
            else:
                res_dic[fname] = '-, %s' % fsign    # not in dir1, but dir2
            
    return res_dic


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print "parameter error"
        exit(-1)

    file1 = sys.argv[1]
    file2 = sys.argv[2]
    if not (os.path.isfile(file1) or os.path.isfile(file2)):
        print "no such files: %s or %s" % (file1, file2)
        exit(-2)

    res_file = str("%s_%s_items.diff" % (file1, file2)).replace(".", "-")
    print ">>", res_file

    res = compare_2files_items(file1, file2)
    if res is not None:
        output = open(res_file, 'w+')
        str_buf = []
        n_cap = 1000

        print "====================================== %s diff item(s) ======================================" % len(res.keys())
        print "%-32s %-32s %-32s" % ("in_dir1", "in_dir2", "file")
        for key in res.keys():
            varr = str(res[key]).split(', ')
            s = "%-32s %-32s %-32s" % (varr[0], varr[1], key)
            print s
            str_buf.append('%s, %s\n' % (res[key], key))
            if len(str_buf) == n_cap:
                output.writelines(str_buf)
                str_buf = []

        # flush all
        if len(str_buf) != 0:
            output.writelines(str_buf)

        output.close()
        print "(%s diff)" % len(res.keys())

    exit(len(res.keys()))

