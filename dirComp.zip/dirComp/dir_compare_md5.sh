#!/bin/sh

mypath=$(cd `dirname $0`; pwd)
file_item_comp=$mypath/item_compare.py
tmp_dir=$mypath/compare_$(date '+%Y%m%d%H%M%S')
dir1=$1
dir2=$2


function myecho(){
    str=$1
    color=$2
    bold=$3
    [ -z $color ] && color="b1"
    color_index=34
    case $color in
        "r" | "red") color_index="00;31m";;
        "g" | "green") color_index="00;32m";;
        "y" | "yellow") color_index="00;33m";;
        "b" | "blue") color_index="00;34m";;
        "p" | "purple") color_index="00;35m";;
        "a" | "azure") color_index="00;36m";;
        "w" | "white") color_index="00;37m";;
        "r1" | "red") color_index="01;31m";;
        "g1" | "green") color_index="01;32m";;
        "y1" | "yellow") color_index="01;33m";;
        "b1" | "blue") color_index="01;34m";;
        "p1" | "purple") color_index="01;35m";;
        "a1" | "azure") color_index="01;36m";;
        "w1" | "white") color_index="01;37m";;
        *) color_index="01;34m";;
    esac

    # echo -e "\e[0;$color_index;1m$str\e[0m"
    # echo -e "\033[${color_index}m${str}\033[0m"
    echo -e "\e[${color_index}${str}\e[00m"
}

function compare_2files_items(){
	file1=$1
	file2=$2 
	[ ! -f $file1 ] || [ ! -f $file2 ] && echo "no such files: $file1 or $file2"
	file1_md5=$(md5sum $file1)
	file2_md5=$(md5sum $file2)
	if [ "$file1_md5" == "$file2_md5" ]; then
		return 0
	else
        python $file_item_comp $file1 $file2
        return $?
    fi	
}

echo ""
echo "mypath: "$mypath
echo "file_item_comp: "$file_item_comp
echo "tmp_dir: "$tmp_dir
echo ""
myecho "************************************************************"
myecho "文件对比(MD5): $dir1/ & $dir2/"
myecho "************************************************************"
echo ""

# get info
mkdir -p $tmp_dir

myecho "(1/3): 获取目录/文件信息" "b"
cd $mypath; cd $dir1
find . -exec ls -ald {} \; | awk '{print $1,$3,$4,$5,$9}' > $tmp_dir/dir1.fileInfo
find . -type f | xargs md5sum > $tmp_dir/dir1.fileMD5

cd $mypath; cd $dir2
find . -exec ls -ald {} \; | awk '{print $1,$3,$4,$5,$9}' > $tmp_dir/dir2.fileInfo
find . -type f | xargs md5sum > $tmp_dir/dir2.fileMD5

# compare file info
cd $tmp_dir
echo ""
myecho "(2/3): 目录/文件比较" "b"
compare_2files_items dir1.fileInfo dir2.fileInfo
ret1=$?
if [ $ret1 -eq 0 ]; then
    myecho ": 所有目录/文件的名称、权限、大小一致" "y"
fi
echo ""
myecho "(3/3): 文件内容比较" "b"
compare_2files_items dir1.fileMD5 dir2.fileMD5
ret2=$?
if [ $ret2 -eq 0 ]; then
    myecho ": 所有文件的内容一致" "y"
fi
echo ""

if [ $ret1 -eq 0 ] && [ $ret2 -eq 0 ]; then
    myecho ": $dir1与$dir2 一致" "g1"
else
    myecho ": $dir1与$dir2 不一致" "r1"
fi
echo "(END)"

