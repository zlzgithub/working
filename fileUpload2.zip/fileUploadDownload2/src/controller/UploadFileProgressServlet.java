package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import util.FileUploadInfo;

public class UploadFileProgressServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String responseContent = "";

		Object obj = request.getSession().getAttribute("uploadInfo");
		if (obj == null) {
			responseContent = "{'status:' 0, 'msg':'NoData'}";
		} else {
			FileUploadInfo uploadInfo = (FileUploadInfo) obj;
			responseContent = uploadInfo.toString();
			if (uploadInfo.getUploadPercent() == 100.0) {
				request.getSession().setAttribute("uploadInfo", null);
			}
		}
		System.out.println("文件上次情况：" + responseContent);
		response.setContentType("text/html; charset=Utf-8");
		response.getWriter().print(responseContent);
	}
}