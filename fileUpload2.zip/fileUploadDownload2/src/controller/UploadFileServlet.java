package controller;

import java.io.IOException;
import java.util.Date;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileUploadBase;

import util.FileUploadInfo;
import util.FileUploadUtil;

public class UploadFileServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		FileUploadInfo fileUploadInfo = new FileUploadInfo();

		try {
			long start = System.currentTimeMillis();
			System.out.println("开始上传文件.........");
			Map<String, String> params = FileUploadUtil.upload(request);
			System.out.println("文件上传完成.........");
			System.out.println("文件上次用时:" + (System.currentTimeMillis() - start)
					+ "毫秒");
		}catch (FileUploadBase.FileSizeLimitExceededException e) {
			e.printStackTrace();
			System.out.println("aaaaaaaaaaa");
			fileUploadInfo.setStatus(1);
			fileUploadInfo.setMsg("单个文件超出最大值！！！");
			request.getSession().setAttribute("uploadInfo", fileUploadInfo);
			return;
		} catch (FileUploadBase.SizeLimitExceededException e) {
			e.printStackTrace();
			fileUploadInfo.setStatus(2);
			fileUploadInfo.setMsg("上传文件的总的大小超出限制的最大值！！！");
			request.getSession().setAttribute("uploadInfo", fileUploadInfo);
			System.out.println("aaaaaaaaaa2a");
			return;
		} catch (Exception e) {
			e.printStackTrace();
			fileUploadInfo.setStatus(3);
			fileUploadInfo.setMsg("上传失败");
			request.getSession().setAttribute("uploadInfo", fileUploadInfo);
			System.out.println("aaaaaaaaaa3a");
			return;
		}
	}
}