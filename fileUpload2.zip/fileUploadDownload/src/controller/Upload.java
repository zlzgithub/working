package controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.DefaultFileItemFactory;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

@SuppressWarnings("deprecation")
public class Upload extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("rawtypes")
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		DefaultFileItemFactory factory = new DefaultFileItemFactory();
		HttpSession session = request.getSession();
		ServletFileUpload upload = new ServletFileUpload(factory);
		try {
			List tempList = upload.parseRequest(request);
			Iterator it = tempList.iterator();
			while (it.hasNext()) {
				FileItem item = (FileItem) it.next();
				if (item.isFormField()) {
					/** 处理常规文本域 **/
				} else {
					if (item.getName() != null && !item.getName().equals("")) {
						Long size = item.getSize();
						System.out.println(size);
						File tempFile = new File("I:/" + item.getName());
						byte[] b = new byte[1024 * 8];

						InputStream in = item.getInputStream();
						OutputStream out = new FileOutputStream(tempFile);
						int len = 0;
						int current = 0;
						session.setAttribute("total", size);
						System.out.println("start");
						while ((len = in.read(b)) > 0) {
							current += len;
							Thread.sleep(10);
							System.out.println(current + "/" + size);
							session.setAttribute("current", current);
							out.write(b, 0, len);
						}
						System.out.println("done");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}