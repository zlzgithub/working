var total = 0;//文件总大小  
var current = 0;//当前大小  
var present= 0;//百分比  
var timer = null;//定时触发事件  
(function($){  
    $(function(){  
        $('#btn').click(function(){
            timer = window.setInterval('getData()', 500);  
            $('#btn').attr('disabled','disabled');  
            $('#form').submit();  
        });  
    });  
})(jQuery);

var getData = function(){  
    $.ajax({
        url:'servlet/GetProgress',  
        success:function(msg){  
            msg = eval('(' + msg + ')');  
            total = msg.total;  
            current = msg.current;
            present= (current/total)*100;
            if(present==100){
            	alert("done");
                $('#btn').attr('disabled','');  
                window.clearInterval(timer);  
            }
            $('#data').attr('innerHTML',present.toFixed(2)+'%');  
        }
    });  
};